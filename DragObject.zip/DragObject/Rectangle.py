from PyQt5.QtCore import QRect, QPoint

# 自定义QRect(矩形)类
class Rectangle(QRect):
    def __init__(self, *args, parent = None):
        super(Rectangle,self).__init__(*args)
        # 是否可以移动
        self.moveable = False
        # 是否可以缩放
        self.resizeable = False
        self.label = ""

    # 返回右下角的点QPoint
    def bottomRight(self):
        point = super().bottomRight()
        return point

    # 判断鼠标是否点在了右下角(误差为+-x)
    def ClickedBottomRight(self, x):
        # print(QRect(self.bottomRight() - QPoint(2,2), self.bottomRight()+QPoint(2,2)))
        return QRect(self.bottomRight() - QPoint(x, x), self.bottomRight() + QPoint(x, x))

    def SetText(self, string):
        self.label = string

    def GetText(self):
        return self.label