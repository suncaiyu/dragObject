import sys
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from MainWindow import *
from Rectangle import *
from MyLineEdit import *

class MainWindow_Ui(QMainWindow,Ui_MainWindow):
    def __init__(self, parent=None):
        super(MainWindow_Ui, self).__init__(parent)
        self.setupUi(self)
        self.myRect = Rectangle(QRect(20,30,50,80))
        self.startoffsetX = -1
        self.startoffsetY = -1
        self.myRect.SetText("lululu")

    def paintEvent(self, e):
        painter = QPainter(self)
        pen = QPen()
        if self.myRect.moveable ==True:
            pen.setWidth(3)
            painter.setPen(pen)
        if self.myRect.resizeable == True:
            pen.setColor(Qt.red)
            painter.setPen(pen)
        painter.drawRect(self.myRect)
        if self.myRect.GetText() != "":
            painter.drawText(self.myRect,Qt.AlignCenter, self.myRect.GetText())
        painter.end()

    def mousePressEvent(self, e):
        myjudgetRect = self.myRect.adjusted(3,3,-3,-3)
        if myjudgetRect.contains(e.pos()):
            self.myRect.moveable = True
            self.startoffsetX = e.pos().x() - self.myRect.x()
            self.startoffsetY = e.pos().y() - self.myRect.y()
            self.update()
        if ((self.myRect.ClickedBottomRight(2)).contains(e.pos())):
            self.myRect.resizeable = True
            self.update()

    def mouseMoveEvent(self, e):
        if self.myRect.moveable == True:
            self.myRect.setRect(e.pos().x() - self.startoffsetX, e.pos().y() - self.startoffsetY,
                                self.myRect.width(), self.myRect.height())
            self.update()
        if self.myRect.resizeable == True:
            self.myRect.setBottomRight(e.pos())
            self.update()

    def mouseDoubleClickEvent(self, e):
        if self.myRect.contains(e.pos()):
            lineEdit = MyLineEdit(self)
            lineEdit.move(self.myRect.x(),self.myRect.y())
            lineEdit.resize(self.myRect.width() + 1, self.myRect.height() + 1)
            lineEdit.show()
            lineEdit.returnPressed.connect(lambda :self.myRect.SetText(lineEdit.text()))

    def mouseReleaseEvent(self, e):
        self.myRect.moveable = False
        self.myRect.resizeable = False
        self.update()

if __name__ =="__main__":
    app=QApplication(sys.argv)
    myWin = MainWindow_Ui()
    myWin.show()
    sys.exit(app.exec_())
