from PyQt5.QtWidgets import QLineEdit
from PyQt5.QtGui import QKeyEvent
from PyQt5.QtCore import Qt

class MyLineEdit(QLineEdit):
    def __init__(self, *args, parent = None):
        super(MyLineEdit, self).__init__(*args)
        self.setFocus()

    def keyPressEvent(self, e):
        super().keyPressEvent(e)
        if e.key() == Qt.Key_Escape:
            self.close()
        if e.key() == Qt.Key_Return:
            super().keyPressEvent(e)
            self.close()
